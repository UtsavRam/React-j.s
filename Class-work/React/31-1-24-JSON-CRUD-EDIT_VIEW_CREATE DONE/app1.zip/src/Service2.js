import React from 'react'

function Service2() {
  return (
    <div>
      Service 2
    </div>
  )
}

export default Service2
