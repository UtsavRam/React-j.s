import React from 'react'

function Service3() {
  return (
    <div>
      Service 3
    </div>
  )
}

export default Service3
